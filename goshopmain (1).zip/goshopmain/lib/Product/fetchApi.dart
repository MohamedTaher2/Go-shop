import 'package:flutter/material.dart';
import 'package:goshop/Product/ProductApi.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class FetchApi{

  Future <List <ProdectModel>? >fetchProduct() async{
    http.Response response = await http.get(Uri.http('https://fakestoreapi.com', 'products/1'));

    if(response.statusCode == 200){
      var jsonData =jsonDecode(response.body) ;
      List<ProdectModel> products=[];
      for(var item in jsonData){
        ProdectModel prodect = ProdectModel(item['id'], item['title'],item['image'] ,item['price'] );
        products.add(prodect);
      }
      return products;
    }

      return null;




  }


}