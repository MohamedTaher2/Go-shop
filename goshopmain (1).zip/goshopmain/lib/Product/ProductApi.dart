
class ProdectModel{
  late int id;
  late String title , image,price;
  ProdectModel(this.id,this.title,this.image,this.price);

  ProdectModel.FromJsom(Map<String,dynamic>map)
  {
    this.id = map['id'];
    this.title = map['title'];
    this.image = map['image']['url'];
    this.price = map['price'];
  }


}