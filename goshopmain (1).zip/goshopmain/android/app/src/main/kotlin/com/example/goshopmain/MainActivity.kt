package com.example.goshopmain

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
